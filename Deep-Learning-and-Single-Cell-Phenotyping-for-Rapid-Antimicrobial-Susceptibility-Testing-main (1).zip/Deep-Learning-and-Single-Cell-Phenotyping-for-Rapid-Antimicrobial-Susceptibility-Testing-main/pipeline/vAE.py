def create_encoder():
    '''Create Densenet121 based encoder '''
    pass

def create_decoder():
    '''Custom, short encoder '''